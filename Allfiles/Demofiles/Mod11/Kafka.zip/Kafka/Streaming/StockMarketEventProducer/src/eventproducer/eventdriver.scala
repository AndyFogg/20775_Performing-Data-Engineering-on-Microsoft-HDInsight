/**
  * Created by JohnS on 09/06/2017.
  */

package eventproducer

import java.util.Properties
import org.apache.kafka.clients.producer.Callback
import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerConfig
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.clients.producer.RecordMetadata
import org.json4s.JsonDSL._
import org.json4s.jackson.JsonMethods._
import scala.util.Random

object eventdriver {

  var inputOptions: Map[Symbol, Any] = _

  def main(inputArguments: Array[String]): Unit = {

    // Parse the command line arguments
    inputOptions = ClientArgumentParser.parseArguments(Map(), inputArguments.toList)
    ClientArgumentParser.verifyArguments(inputOptions)
    println(inputOptions)

    // Retrieve the values of the command line arguments
    val bootstrapServers: String = inputOptions(Symbol(ClientArgumentKeys.BootstrapServers)).asInstanceOf[String]
    val topicName: String = inputOptions(Symbol(ClientArgumentKeys.TopicName)).asInstanceOf[String]

    // Create the dumy stock market tickers and starting prices
    var marketData = scala.collection.mutable.Map(
      "ABCD" -> 10,
      "DEFG" -> 15,
      "WXYZ" -> 5,
      "HJKL" -> 22,
      "YUFG" -> 66,
      "LKJK" -> 98,
      "TYIO" -> 28,
      "BMKT" -> 53,
      "AHUD" -> 29,
      "LQUC" -> 42)

    // Construct a Properties object for the producer
    var props: Properties = new Properties
    props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)
    props.put(ProducerConfig.ACKS_CONFIG, "all")
    props.put(ProducerConfig.RETRIES_CONFIG, "5")
    props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer")
    props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer")

    // Construct the producer
    val producer = new KafkaProducer[String, String](props)

    try {
      var currentEventCount: Long = 0

      // Simulate stock market price events
      while (true) {
        val index: Int = Random.nextInt(marketData.size)
        val ticker: String = marketData.toIndexedSeq(index)._1
        var price: Int = marketData.toIndexedSeq(index)._2

        price += Random.nextInt(10) - 5
        if (price < 0) price = 0
        marketData(ticker) = price

        // Format the ticker and new price as a JSON string
        val jsonData: String = formatData(ticker, price)

        // Create a ProducerRecord from the data
        val data: ProducerRecord[String, String] = new ProducerRecord(topicName, s"Event: $currentEventCount", jsonData)
        currentEventCount += 1
        println(s"Sending Key: $currentEventCount, Data: $jsonData")
        producer.send(data, sendercallback)

        // Wait for a random interval between 1/10 and 1 second
        Thread.sleep(Random.nextInt(10) * 100)
      }
    } catch {
      case e: Exception => println(s"Exception sending message: $e")
    } finally {
      producer.close()
    }

    // Format a ticker and price as a JSON string
    def formatData(ticker: String, price: Int): String = {
      val eventPayload =
        "eventData" -> (("ticker" -> ticker) ~ ("price" -> price))
      val jsonPayload = compact(render(eventPayload))
      return jsonPayload
    }
  }


  // Handle the response from Kafka when the message has been sent
  private object sendercallback extends Callback {

    override def onCompletion(recordMetadata: RecordMetadata, e: Exception): Unit = {
      if (e != null) {
        println(s"Error sending message: $recordMetadata")
      } else {
        val topic = recordMetadata.topic
        val partition = recordMetadata.partition
        val position = recordMetadata.offset
        println(s"Message sent to topic $topic, partition $partition, position $position")
      }
    }
  }
}
