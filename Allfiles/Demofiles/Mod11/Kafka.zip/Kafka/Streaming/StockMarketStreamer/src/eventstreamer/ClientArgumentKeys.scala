/**
  * Created by JohnS on 09/06/2017.
  */

package eventstreamer

object ClientArgumentKeys extends Enumeration {
  val BootstrapServers: String = "bootstrapServers"
  val TopicName: String = "topicName"
  val SinkTopicName: String = "sinkTopicName"
  val DashboardEndpoint: String = "dashpointEndpoint"
}

object ClientArgumentParser {

  type ArgumentMap = Map[Symbol, Any]

  def usageExample(): Unit = {

    val bootstrapServers: String = "<bootstrap-server1,bootstrap-server2,...>"
    val topicName: String = "<topic>"
    val sinkTopicName: String = "<topic>"
    val dashboardEndpoint: String = "<url>"

    println()
    println(s"--bootstrap-servers $bootstrapServers --topic $topicName --sink-topic $sinkTopicName --dashboard-endpoint $dashboardEndpoint")
    println()
  }

  def parseArguments(argumentMap: ArgumentMap, argumentList: List[String]): ArgumentMap = {

    argumentList match {
      case Nil => argumentMap
      case "--bootstrap-servers" :: value :: tail =>
        parseArguments(argumentMap ++ Map(Symbol(ClientArgumentKeys.BootstrapServers) -> value.toString), tail)
      case "--topic" :: value :: tail =>
        parseArguments(argumentMap ++ Map(Symbol(ClientArgumentKeys.TopicName) -> value.toString), tail)
      case "--sink-topic" :: value :: tail =>
        parseArguments(argumentMap ++ Map(Symbol(ClientArgumentKeys.SinkTopicName) -> value.toString), tail)
      case "--dashboard-endpoint" :: value :: tail =>
        parseArguments(argumentMap ++ Map(Symbol(ClientArgumentKeys.DashboardEndpoint) -> value.toString), tail)
      case option :: tail =>
        println()
        println("Unknown option: " + option)
        println()
        usageExample()
        sys.exit(1)
    }
  }

  def verifyArguments(argumentMap: ArgumentMap): Unit = {

    assert(argumentMap.contains(Symbol(ClientArgumentKeys.BootstrapServers)))
    assert(argumentMap.contains(Symbol(ClientArgumentKeys.TopicName)))
    assert(argumentMap.contains(Symbol(ClientArgumentKeys.SinkTopicName)))
    assert(argumentMap.contains(Symbol(ClientArgumentKeys.DashboardEndpoint)))
  }
}

