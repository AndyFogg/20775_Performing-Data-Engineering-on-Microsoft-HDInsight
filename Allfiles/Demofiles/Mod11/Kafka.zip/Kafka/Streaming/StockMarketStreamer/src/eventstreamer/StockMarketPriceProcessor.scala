/**
  * Created by JohnS on 12/06/2017.
  */

package eventstreamer

import org.apache.kafka.streams.processor.{Processor, ProcessorContext, ProcessorSupplier}
import org.apache.kafka.streams.state.KeyValueStore

import scala.collection.mutable.ListBuffer
import org.json4s.DefaultFormats
import org.apache.http.client._
import org.apache.http.client.methods._
import org.apache.http.impl.client._
import com.google.gson._
import org.apache.http.entity.StringEntity

// Processor that processes stock market events and displays the results in Power BI
// The type parameters are the types of the key (String - the stock ticker), and the data (Int - the price)
// The output consists of a stream holding the same data
// The processor calculates the running average price and cumulative number of stock market movements for each item
class StockMarketPriceProcessor extends Processor[String, Int] {

  private var context: ProcessorContext = _

  // The state stores that hold the data used for calculating the average price and number of price movements.
  private var avgPrices: KeyValueStore[String, Double] = _
  private var numPrices: KeyValueStore[String, Integer] = _

  // The prices variable buffers the prices received form the input stream
  private var prices: ListBuffer[(String, Int)] = _

  // Initialization
  override def init(context: ProcessorContext): Unit = {
    this.context = context // Cache the processor context. It is used in other methods in this object
    this.context.schedule(1000) // Push the data out of this object every two seconds
    this.avgPrices = context.getStateStore("AvgPrices").asInstanceOf[KeyValueStore[String, Double]]
    this.numPrices = context.getStateStore("NumPrices").asInstanceOf[KeyValueStore[String, Integer]]
    this.prices = new ListBuffer[(String, Int)]
    println("StockMarketPriceProcessor initialized")
  }

  // Calculate the running average price and cumulative number of movements retrieved from the input stream
  override def process(ticker: String, price: Int): Unit = {

    try {
      var numMoves: Int = 0
      val oldNumMoves = Option(numPrices.get(ticker)) match {
        case Some(value) => numMoves = value + 1
        case None => numMoves = 1
      }

      var avgPrice: Double = 0
      val oldAvgPrice = Option(avgPrices.get(ticker)) match {
        case Some(value) => avgPrice = (value * (numMoves - 1) + price) / numMoves
        case None => avgPrice = price
      }

      // Store the results back in the state stores
      numPrices.put(ticker, numMoves)
      avgPrices.put(ticker, avgPrice)

      // Visualize the results in Power BI
      displayResults(new StockMarketPriceData(ticker, numMoves, avgPrice))

      // Add the ticker and latest price to the Prices list.
      this.prices.append((ticker, price))

      println(s"StockMarketPriceProcessor: Ticker $ticker, Avg Price $avgPrice, Num Movements: $numMoves")

    } catch {
      case ex: Exception => println(s"Exception in StockMarketPriceProcessor: ${ex.getMessage}\nEvent discarded\n")
    }
  }

  // Forward the stream data (in the prices variable) out to the next processor in the pipeline
  override def punctuate(timestamp: Long): Unit = {

    // Iterate through the prices list and push out the current prices
    for(priceData <- prices)
    {
      context.forward(priceData._1, priceData._2.toString) // Sink topic data should be strings
      println(s"StockMarketPriceProcessor: Sent $priceData")
    }

    context.commit
  }

  // Reclaim any resources used by the processor
  override def close: Unit = {
     // Do nothing - no resources to tidy up
  }

  // Visualize the data using Power BI
  private def displayResults(data: StockMarketPriceData) : Unit = {
    try {
      // Format the data as a JSON string
      implicit val formats = DefaultFormats
      val jsonData = "[" + new Gson().toJson(data) + "]"

      // Post the data to the endpoint for the Power BI dashboard
      val endpoint: String = streamdriver.inputOptions(Symbol(ClientArgumentKeys.DashboardEndpoint)).asInstanceOf[String]
      val post = new HttpPost(endpoint)
      post.setEntity(new StringEntity(jsonData))
      val client: HttpClient = HttpClients.createDefault
      val response = client.execute(post)

      // Log the responses
      println("StatisticsBolt response:")
      response.getAllHeaders.foreach(arg => println(arg))
    } catch {
      case ex: Exception => println("Error in StockMarketPriceProcessor: " + ex.getMessage)
    }
  }
}

object StockMarketPriceProcessorSupplier extends ProcessorSupplier[String, Int] {
  override def get: Processor[String, Int] = {
    return new StockMarketPriceProcessor
  }
}

//case class StockMarketPriceData(Ticker: String, Movements: Int, AveragePrice: Double)
class StockMarketPriceData(pTicker: String, pMovements: Int, pAveragePrice: Double)
{
  var Ticker: String = pTicker;
  var Movements: Int = pMovements;
  var AveragePrice: Double = pAveragePrice;
  println(s"Creating record for ${Ticker}");
}