/**
  * Created by JohnS on 11/06/2017.
  */

package eventstreamer

import scala.collection.mutable.ListBuffer
import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import org.apache.kafka.streams.processor.{Processor, ProcessorContext, ProcessorSupplier}

// Processor that retrieves and parses stock market events
// The type parameters are the types of the key (String), and the event data (a JSON String) in the topic being read
// The output consists of a stream holding the stock ticker and the current price
class StockMarketSourceProcessor extends Processor[String, String] {

  private var context: ProcessorContext = _

  // The prices list holds the stock ticker (a String) and the price recorded in each event.
  private var prices: ListBuffer[(String, Int)] = _

  // Initialization
  override def init(context: ProcessorContext): Unit = {
    this.context = context // Cache the processor context. It is used in other methods in this object
    this.context.schedule(1000) // Push the data out of this object every second
    this.prices = new ListBuffer[(String, Int)]
    println("StockMarketSourceProcessor initialized")
  }

  // Process each item retrieved from the input topic for the processor
  override def process(key: String, data: String): Unit = {

    try {
      // Parse the JSON data into a ticker and price.
      // The JSON data has the form {"eventData":{"ticker":"LQUC","price":46}}
      val mapper: ObjectMapper = new ObjectMapper
      val stockPriceData: JsonNode = mapper.readTree(data)
      if (stockPriceData.has("eventData")){
        val stockPriceRecord = stockPriceData.get("eventData")
        val stockTicker: String = stockPriceRecord.get("ticker").asText
        val stockPrice: Int = stockPriceRecord.get("price").asInt
        println(s"StockMarketSourceProcessor: Ticker $stockTicker, Price $stockPrice")

        // Add the ticker and latest price to the Prices list.
        this.prices.append((stockTicker, stockPrice))
      }

    } catch {
      case ex: Exception => println(s"Exception in StockMarketSourceProcessor: ${ex.getMessage}\nEvent discarded\n")
    }
  }

  // Periodically push the processed data (in the prices variable) out to the next processor in the pipeline
  override def punctuate(timestamp: Long): Unit = {

    // Iterate through the prices list and push out the current prices
    for(priceData <- prices)
    {
      context.forward(priceData._1, priceData._2)
      println(s"StockMarketSourceProcessor: Sent $priceData")
    }

    context.commit
  }

  // Reclaim any resources used by the processor
  override def close: Unit = {
    // Do nothing - no resources to tidy up
  }
}

object StockMarketSourceProcessorSupplier extends ProcessorSupplier[String, String] {
  override def get: Processor[String, String] = {
    return new StockMarketSourceProcessor
  }
}
