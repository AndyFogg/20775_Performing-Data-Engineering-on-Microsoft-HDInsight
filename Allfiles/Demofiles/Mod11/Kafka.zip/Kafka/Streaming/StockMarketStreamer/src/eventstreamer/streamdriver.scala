/**
  * Created by JohnS on 09/06/2017.
  */

package eventstreamer

import java.util.Properties

import org.apache.kafka.clients.consumer.ConsumerConfig
import org.apache.kafka.common.serialization.Serdes
import org.apache.kafka.streams.StreamsConfig
import org.apache.kafka.streams.processor.TopologyBuilder
import org.apache.kafka.streams.state.Stores
import org.apache.kafka.streams.KafkaStreams

object streamdriver {

  var inputOptions: Map[Symbol, Any] = _

  def main(inputArguments: Array[String]): Unit = {

    // Parse the command line arguments
    inputOptions = ClientArgumentParser.parseArguments(Map(), inputArguments.toList)
    ClientArgumentParser.verifyArguments(inputOptions)
    println(inputOptions)

    // Retrieve the values of the command line arguments
    val bootstrapServers: String = inputOptions(Symbol(ClientArgumentKeys.BootstrapServers)).asInstanceOf[String]
    val topicName: String = inputOptions(Symbol(ClientArgumentKeys.TopicName)).asInstanceOf[String]
    val sinkTopicName: String = inputOptions(Symbol(ClientArgumentKeys.SinkTopicName)).asInstanceOf[String]

    // Construct a Properties object for the streaming topology
    var props: Properties = new Properties
    props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)
    props.put(StreamsConfig.APPLICATION_ID_CONFIG, "StockMarketApp")
    props.put(StreamsConfig.STATE_DIR_CONFIG, "E:\\Labfiles\\Logs")
    props.put(StreamsConfig.KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
    props.put(StreamsConfig.VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
    props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest")

    try {
       // Create state stores for holding statistical data about stocks (average price, number of movements)
      var avgPriceStore = Stores.create("AvgPrices").withKeys(Serdes.String).withValues(Serdes.Double).persistent.build
      var numPricesStore = Stores.create("NumPrices").withKeys(Serdes.String).withValues(Serdes.Integer).persistent.build

      // Construct the streaming topology (simple pipeline)
      var builder: TopologyBuilder = new TopologyBuilder
      builder.addSource("SOURCE", topicName)
        .addProcessor("PRICEREADER", eventstreamer.StockMarketSourceProcessorSupplier, "SOURCE")
        .addProcessor("PRICEPROCESSOR", eventstreamer.StockMarketPriceProcessorSupplier, "PRICEREADER")
        .addStateStore(avgPriceStore, "PRICEPROCESSOR")
        .addStateStore(numPricesStore, "PRICEPROCESSOR")
        .addSink("SINK", sinkTopicName, "PRICEPROCESSOR")
      println("StreamDriver: Topology built")

      // Start the topology
      val streamTopology: KafkaStreams = new KafkaStreams(builder, props)
      streamTopology.start
      println("StreamDriver: Topology running")

      // Let the topology run for a minute (60000 ms)
      Thread.sleep(60000)

      // Close the topology
      streamTopology.close()
    } catch {
      case ex: Exception => println(s"Exception in StreamDriver: ${ex.getMessage}")
    }
  }
}
