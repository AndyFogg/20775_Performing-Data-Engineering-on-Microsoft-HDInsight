/**
  * Created by John on 29/06/2017.
  *
  * Simple socket client for receiving stock market price changes
  */

package StructuredStreamReceiver

import org.apache.spark.sql.SparkSession
import org.apache.spark._

import org.apache.log4j.{Level, Logger}


object Sender {
  def main(inputArguments: Array[String]): Unit = {

    // Turn informational logging off (makes the console output easier to read for this example)
    Logger.getLogger("org").setLevel(Level.ERROR)
    Logger.getLogger("akka").setLevel(Level.ERROR)

    // Parse the command line arguments
    val inputOptions: Map[Symbol, Any] = ClientArgumentParser.parseArguments(Map(), inputArguments.toList)
    ClientArgumentParser.verifyArguments(inputOptions)
    println(inputOptions)

    // Retrieve the sender address and port from the command line arguments
    val sender: String = inputOptions(Symbol(ClientArgumentKeys.Sender)).asInstanceOf[String]
    val port: Int = inputOptions(Symbol(ClientArgumentKeys.Port)).asInstanceOf[String].toInt

    try {

      // Create a Spark session
      val config: SparkConf = new SparkConf
      config.setAppName("StockMarket")
      config.set("spark.streaming.driver.writeAheadLog.allowBatching", "true")
      config.set("spark.streaming.driver.writeAheadLog.batchingTimeout", "60000")
      config.set("spark.streaming.receiver.writeAheadLog.enable", "true")
      config.set("spark.streaming.receiver.writeAheadLog.closeFileAfterWrite", "true")
      config.set("spark.streaming.stopGracefullyOnShutdown", "true")
      config.setMaster("local[*]") // change to "spark://host:port to run in a Spark cluster

      val spark: SparkSession = SparkSession.builder.config(config).getOrCreate()

      // Create a DataFrame for the input stream containing the stock market events
      val stockMarketEvent = spark.readStream.format("socket").option("host", sender).option("port", port).load()

      // Extract the ticker from each row in the DataFrame
      import spark.implicits._
      val tickers = stockMarketEvent.as[String].map(_.split(",")(0)).toDF("Ticker")

      // Count how many times each ticker occurs in the DataFrame
      val tickerCounts = tickers.groupBy("Ticker").count

      // Display the tickers and counts
      val output = tickerCounts.writeStream.outputMode("complete").format("console").start()

      output.awaitTermination()

    } catch {
      case e: Exception => println(s"Exception processing message: $e")
    }
  }
}
