/**
  * Created by John on 29/06/2017.
  *
  * Simple socket sender for simulating stock market price changes
  */

package StockMarketSocketSender

import scala.util.Random
import java.net.{ServerSocket, Socket}
import java.io._


object Sender {
  def main(inputArguments: Array[String]): Unit = {

    // Parse the command line arguments
    val inputOptions: Map[Symbol, Any] = ClientArgumentParser.parseArguments(Map(), inputArguments.toList)
    ClientArgumentParser.verifyArguments(inputOptions)
    println(inputOptions)

    // Retrieve the port from the command line arguments
    val port: Int = inputOptions(Symbol(ClientArgumentKeys.Port)).asInstanceOf[String].toInt

    // Create a socket for sending stock market data to a receiver
    val server: ServerSocket = new ServerSocket(port)

    // Listen for a connection from a client
    val socket: Socket = server.accept()

    // Create an output stream for sending data down the socket
    val output: PrintStream = new PrintStream(socket.getOutputStream)

    // Create the dumy stock market tickers and starting prices
    var marketData = scala.collection.mutable.Map(
      "ABCD" -> 10,
      "DEFG" -> 15,
      "WXYZ" -> 5,
      "HJKL" -> 22,
      "YUFG" -> 66,
      "LKJK" -> 98,
      "TYIO" -> 28,
      "BMKT" -> 53,
      "AHUD" -> 29,
      "LQUC" -> 42)

    try {
      var currentEventCount: Long = 0

      // Simulate stock market price events and send them down the socket
      while (true) {

        // Generate the data to send down the socket
        val index: Int = Random.nextInt(marketData.size)
        val ticker: String = marketData.toIndexedSeq(index)._1
        var price: Int = marketData.toIndexedSeq(index)._2

        price += Random.nextInt(10) - 5
        if (price < 0) price = 0
        marketData(ticker) = price

        // Format the ticker and new price as a CSV string
        val data: String = s"$ticker, $price"
        println(s"Sending: $data")

        // Send the data
        output.println(data)
        output.flush()

        // Wait for a random interval between 1/10 and 1 second
        Thread.sleep(Random.nextInt(10) * 100)
      }
    } catch {
      case e: Exception => println(s"Exception sending message: $e")
    } finally {
      // Close the socket if the program is terminated
      println("Closing socket")
      socket.close()
    }
  }
}
