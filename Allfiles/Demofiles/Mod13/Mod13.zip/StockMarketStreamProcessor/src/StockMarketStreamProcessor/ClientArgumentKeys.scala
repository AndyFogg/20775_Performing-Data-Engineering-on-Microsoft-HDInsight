/**
  * Created by JohnS on 29/06/2017.
  */

package StockMarketStreamProcessor

object ClientArgumentKeys extends Enumeration {
  val Sender: String = "sender"
  val Port: String = "port"
  val CheckpointDirectory: String = "checkpointDirectory"
}

object ClientArgumentParser {

  type ArgumentMap = Map[Symbol, Any]

  def usageExample(): Unit = {

    val port: String = "<port>"
    val sender: String = "<sender address>"
    val checkpointDirectory: String = "<directory>"

    println()
    println(s"Usage: --sender $sender --port $port --checkpoint-directory $checkpointDirectory")
    println()
  }

  def parseArguments(argumentMap: ArgumentMap, argumentList: List[String]): ArgumentMap = {

    argumentList match {
      case Nil => argumentMap
      case "--sender" :: value :: tail =>
        parseArguments(argumentMap ++ Map(Symbol(ClientArgumentKeys.Sender) -> value.toString), tail)
      case "--port" :: value :: tail =>
        parseArguments(argumentMap ++ Map(Symbol(ClientArgumentKeys.Port) -> value.toString), tail)
      case "--checkpoint-directory" :: value :: tail =>
        parseArguments(argumentMap ++ Map(Symbol(ClientArgumentKeys.CheckpointDirectory) -> value.toString), tail)
      case option :: tail =>
        println()
        println("Unknown option: " + option)
        println()
        usageExample()
        sys.exit(1)
    }
  }

  def verifyArguments(argumentMap: ArgumentMap): Unit = {

    assert(argumentMap.contains(Symbol(ClientArgumentKeys.Sender)))
    assert(argumentMap.contains(Symbol(ClientArgumentKeys.Port)))
    assert(argumentMap.contains(Symbol(ClientArgumentKeys.CheckpointDirectory)))
  }
}
