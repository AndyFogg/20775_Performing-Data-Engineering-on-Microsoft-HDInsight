/**
  * Created by John on 29/06/2017.
  *
  * Simple DStreams processor that receives stock market events from a socket
  * Event data is a CSV string comprising a ticker (4 chars) and a price
  */

package StockMarketStreamProcessor

import org.apache.spark._
import org.apache.spark.streaming._
import org.apache.spark.streaming.dstream.DStream
import org.apache.log4j.{Level, Logger}
import scala.collection.mutable.Set

object StreamProcessor {
  def main(inputArguments: Array[String]): Unit = {

    // Turn informational logging off (makes the console output easier to read for this example)
    Logger.getLogger("org").setLevel(Level.ERROR)
    Logger.getLogger("akka").setLevel(Level.ERROR)

    // Parse the command line arguments
    val inputOptions: Map[Symbol, Any] = ClientArgumentParser.parseArguments(Map(), inputArguments.toList)
    ClientArgumentParser.verifyArguments(inputOptions)
    println(inputOptions)

    // Retrieve the checkpoint directory from the command line arguments
    val checkpointDirectory: String = inputOptions(Symbol(ClientArgumentKeys.CheckpointDirectory)).asInstanceOf[String]

    // Create a streaming context using the createStreamingContext function
    val streamingContext: StreamingContext = StreamingContext.getOrCreate(checkpointDirectory,
      () => createStreamingContext(inputOptions))

    // Start streaming
    streamingContext.start()

    // Stream until terminated or a few minutes have passed
    streamingContext.awaitTermination(120000)
  }

  // Create a streaming context and define the processing to be performed
  def createStreamingContext(options: Map[Symbol, Any]): StreamingContext = {

    // Create a Spark streaming context
    val config: SparkConf = new SparkConf
    config.setAppName("StockMarket")
    config.set("spark.streaming.driver.writeAheadLog.allowBatching", "true")
    config.set("spark.streaming.driver.writeAheadLog.batchingTimeout", "60000")
    config.set("spark.streaming.receiver.writeAheadLog.enable", "true")
    config.set("spark.streaming.receiver.writeAheadLog.closeFileAfterWrite", "true")
    config.set("spark.streaming.stopGracefullyOnShutdown", "true")
    config.setMaster("local[*]") // change to "spark://host:port to run in a Spark cluster
    val sparkContext: SparkContext = new SparkContext(config)

    // Configure the Spark streaming context
    val checkpointDir: String = options(Symbol(ClientArgumentKeys.CheckpointDirectory)).asInstanceOf[String]
    val batchDuration = 5 // 5 second batches
    val streamingContext: StreamingContext = new StreamingContext(sparkContext, Seconds(batchDuration))
    streamingContext.checkpoint(checkpointDir)

    // Create a DStream that connects to the stock market sender socket using the basic socketTextStream source
    val sender: String = options(Symbol(ClientArgumentKeys.Sender)).asInstanceOf[String]
    val port: Int = options(Symbol(ClientArgumentKeys.Port)).asInstanceOf[String].toInt
    val stream = streamingContext.socketTextStream(sender, port)

    // Define the processing for the stream
    doProcessing(streamingContext, stream)

    // Return the streaming context
    return(streamingContext)
  }

  // Specify the processing to perform.
  // The input stream is a collection of RDDs containing string data in the form "<ticker>, <price>"
  def doProcessing(streamingContext: StreamingContext, stream: DStream[String]): Unit = {

    // Perform a foreachRDD transformation to process the data in the stream
    // Iterate through each item in each partition in each RDD in the stream
    val parsedDdata = stream.foreachRDD {rdd =>
      try
      {
        rdd foreachPartition { part =>
          part foreach {stockMarketEvent =>

            // Split the input data into the ticker and price
            val tickerInfo = stockMarketEvent.split(",")

            // Display the parsed data
            println(s"Ticker: ${tickerInfo(0)}, Price: ${tickerInfo(1)}")
          }
        }
      } catch {
        case ex: Exception => val message: String = ex.getMessage
          println(s"General error processing data: $message\nDiscarding data")
      }
    }
  }
}
