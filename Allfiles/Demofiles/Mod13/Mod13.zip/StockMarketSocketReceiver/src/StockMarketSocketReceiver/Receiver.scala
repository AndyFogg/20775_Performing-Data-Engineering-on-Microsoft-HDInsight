/**
  * Created by John on 29/06/2017.
  *
  * Simple socket client for receiving stock market price changes
  */

package StockMarketSocketReceiver

import scala.util.Random
import java.net._
import scala.io._


object Sender {
  def main(inputArguments: Array[String]): Unit = {

    // Parse the command line arguments
    val inputOptions: Map[Symbol, Any] = ClientArgumentParser.parseArguments(Map(), inputArguments.toList)
    ClientArgumentParser.verifyArguments(inputOptions)
    println(inputOptions)

    // Retrieve the sender address and port from the command line arguments
    val sender: String = inputOptions(Symbol(ClientArgumentKeys.Sender)).asInstanceOf[String]
    val port: Int = inputOptions(Symbol(ClientArgumentKeys.Port)).asInstanceOf[String].toInt

    try {
      // Connect to the server socket
      val socket: Socket = new Socket(InetAddress.getByName(sender), port)

      // Receive and display stock market prices
      while (true) {

        lazy val input = new BufferedSource(socket.getInputStream()).getLines

        // Split the input string into the ticker and price
        val tickerInfo = input.next.split(",")

        // Display the results
        println(s"Ticker: ${tickerInfo(0)}, Price: ${tickerInfo(1)}")
      }
    } catch {
      case e: Exception => println(s"Exception receiving message: $e")
    }
  }
}
